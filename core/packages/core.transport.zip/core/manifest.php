<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8194db81e14922d14a3297a924d3c553',
      'native_key' => 'core',
      'filename' => 'modNamespace/c1eec95b206b32ea5028396ba6b49ff6.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '597135e7a6c2067379ee1ca3f7cac64b',
      'native_key' => 1,
      'filename' => 'modWorkspace/a6ca240d027bf5699479680de2fc2e74.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '363bf6cc8ea852ce85df6c4e98c8e6e4',
      'native_key' => 1,
      'filename' => 'modTransportProvider/4646b2b4bf648f6b7f2280f60f5bf4bc.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4edc5252b7a55c7d7a9e8a59519951c2',
      'native_key' => 'topnav',
      'filename' => 'modMenu/fb74bda03fd05e38545ddb7eef7d1caf.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3a26924e0a0d0960aec3c2afde88b99c',
      'native_key' => 'usernav',
      'filename' => 'modMenu/560339dda9b57c2a0ab3bc06ffcf6a19.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '775de3542501958e18fb1ebe2bfbc125',
      'native_key' => 1,
      'filename' => 'modContentType/6343b2505bca58ca0b9cea996f105bfb.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'cbff5bb645356b9d1aba74ac8544756e',
      'native_key' => 2,
      'filename' => 'modContentType/66ead1c1674f204ed3ebfb1fd1fc7757.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '19c54d0d0bdad8d50da7981bba2279b8',
      'native_key' => 3,
      'filename' => 'modContentType/f52611c131384ead820a421eadda9ccd.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f968afde6457334ba7d7dbcdfd2d61d5',
      'native_key' => 4,
      'filename' => 'modContentType/c63e4918b4ada77b4ade42b0a9b37c44.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '03c5a77f77ef70b3d8a18b4d61b953cd',
      'native_key' => 5,
      'filename' => 'modContentType/d7055c7759e25a901fe6de53ee345728.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '7e8ce207559f911d86c67f04546876e2',
      'native_key' => 6,
      'filename' => 'modContentType/abbd0c540ce3dd0821b9cd60f91b5205.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '09703399c1214b56cfa4451c58826556',
      'native_key' => 7,
      'filename' => 'modContentType/db69e5e4793157166f0912cc21e7ffb6.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '74a019274c55e98d2cb7290a190e0d37',
      'native_key' => 8,
      'filename' => 'modContentType/ecbd4586aef2b911c291ea2aa9ad6f57.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '857e7cfe798aca2446fd618946fa04a1',
      'native_key' => NULL,
      'filename' => 'modClassMap/498efc695d52068b06d7506772f9b3a5.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '09428ce819fa1ab3841d4bc3dcfc4daf',
      'native_key' => NULL,
      'filename' => 'modClassMap/446a1522a0ddfe738394a5230de6f3f4.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'bc2d08a34afffba3a250886c0fc6177c',
      'native_key' => NULL,
      'filename' => 'modClassMap/37dd61c7eb19b1bcd516daabb9d65fe8.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '91361eb3c7162d9f16ff82bb294938c3',
      'native_key' => NULL,
      'filename' => 'modClassMap/67dcdaaf422bf466a260e7c2efaf0366.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b1a59b5853a0cd1503561d33004477b5',
      'native_key' => NULL,
      'filename' => 'modClassMap/f70b71ff4cc2644be5a9a6faa37ad494.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd92f86bb34975a9a65b1e8211332db27',
      'native_key' => NULL,
      'filename' => 'modClassMap/3e27e11c01c67f723d88f34aef86cd48.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'bf593cc5ce0a18922567bde1a086906c',
      'native_key' => NULL,
      'filename' => 'modClassMap/f610725fe7cd74219ce955e7cc1c3580.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3204eae6bba2857bee9ca4a62d15f936',
      'native_key' => NULL,
      'filename' => 'modClassMap/dab600186f33777a485db9c7830fea94.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ed2d644cc20acf0ba63e575e7f93834d',
      'native_key' => NULL,
      'filename' => 'modClassMap/7d6ae988a70ca84167dcbc9c1cfdc724.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ea531581f2f9ac36dbfd993ca775920',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/41dce553e14fbc25352586d3f645c062.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '513653d9302cf39b10fa215420e98297',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/0521edcd92b660503ca464a0d56d610d.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cac3e51febb0c55c5ec9fb707b7197c2',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/6aa02375401a63fe08aba6496a0103b3.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9924acaeb83508492fc99b3d4845e859',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/037e835c22b94e22e1d186c2dc230159.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb590ae87c6404bf1d468eb5fb148619',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/9b6124237675d6fc27b6e949ad65da2d.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1bc825257d56b9400c60492dd6e6bb0',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/f3b2a7c16db50a94fd87062dc32566a3.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6aceceb3fbdcf9e61680656c178e5c74',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/afc5919a27a0026e09e5638717ba59da.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efbd05bbfe01acfe4eca826911439c34',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/e9d5752b6d24b24f868e21c1d8d630f9.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2160f314fd5935cfa27c23b26dec56de',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/eada8e25635b2b4dce258d5c28f5a124.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa5445af7880759ab621e3527e60c853',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/f3c3b8b66f70b311a6c306dbf6afed10.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '989441af44b996106e7b644e3d891728',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/3e9f87e5b88170a044c6380bc5e58339.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b54edf9e9ec83a0376e501a221a28e8',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/0cc310438b29aa2be3ec15e4c57bc53e.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5deb11e261ee14380c47edd1f509bd99',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/430fe0158d15287ea78f5dd2d3d1a45b.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bf92e45439e201a00d76eb0ec080f43',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/3d5c09e30e88627cb7fddbcf06aca3d3.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed7adebc7a511a807e08a6df4cd082fa',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/8cd208addb8acc296da92438f21bec79.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9617da1eafed868111417e1054c4a179',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/6b2d030bf8ef247a7284e335da716229.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '383fc2d12bd2505b397342bef5c2a357',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/883c405641ec6385442da26c6ed70f7a.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b7f26e37a5ceca0dba8a291ef3dd65e',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/3330ea6fead833349699ac910574b029.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7198b7ca2a4b33399d707661e49dd9f9',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/9726f059a637a7c5282d00ea9fe6ebe9.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93c2e93f21e68e8380dcb8754c8edf77',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/c95491f8664f9ff4713d6c364d9f898b.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3847fa0f21b0fb4d0b96e9491c8df279',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/876c0e3b009c8fc3bb52e9a52e3b5a8f.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a0bfbac0e391d9acbc022ea3eb46ff9',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/9a284659b288a575443aed4673667f97.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8aa11a2650999f320a32e2312e99f4d',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/c6683bfbcda64124d20dbe7333a00874.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '743a188972acbfa64d0e870225e6ae3e',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/fa263d65771c7a48a679b252821982c2.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2abda3f8ef19c47a4bccdc17cd2d5da6',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/2f457e08faa321e556f7aa0537ba832d.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77ec2c6bb6d92b095c8ddd4ebb49e9d5',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/7ab9ef2f97d1966898fe304b3c84c837.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b90f042b872bebf517d670f648300eba',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/dc1208bc963163e6fbb39326ad0ddd76.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0044bff62d5399bd00006f6f58c73e9',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/3f4b19924a9c76978435105860d6b92c.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dda744a314610610383b094d49b8cdba',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/7ab39e1c26f1778d7070cc7cec2dab02.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a7c9fc56c2053deed2d16ce5a77f79a',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/8a5a2a8ac10bb18e66896045365b0476.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9feb22557700b8119f43836e59b58f05',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/48e5eae432fd3a8806fd0f2ceb0b6e25.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b09b00b58066d0b48005c36ffe19d7a7',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/1b26d0ce4ff14b07a26678bb9d261770.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33bc7833243796af8b367ca02aae3570',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/58b1cb5e41d08a0229d3c2e0ab54bd52.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e25a923ad144602e7c9583c6268918e',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/9ec6530e7a99c43ebb98d353d12448fe.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '016e70180e371a9c656e9d9feac883c8',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/a3fd675eed0a572adeaf29d49ff5888b.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47c22bc6f507e8821aafd34850f99ec5',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/a294ed07840118856e80db7640255cf0.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4de48930d06a2d1118bf2beeb2d8f3e',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/62a7c34b8b47c8ffc68b34662036ccb7.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95500f046e57a1c120b714f646664e1a',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/1b052d21e6e4fc806033b239c18adc36.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e85046d16a92ee1713614a424471018b',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/16346002074fecf60689af4b0c0167ce.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88ad6aaa17f44bd84796c445732f0e8c',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/1c6c8fe3bbad25d322edb4fdd692a24a.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cc7feff6101a51d8aa7421c3534329ce',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/5bf47c4c8b31dcf785ca8ffbfffebc5b.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e0b6c6ad4193d2bbf9d4d002d8e2fae',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/d3291f22c1b0c12e7158c22f50a80e5e.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '420949e187472f83d10ec9fe2ca825bd',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/3c9192170ac23d9f4e5b18ad2224fd42.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '341031261fdfe6f3cbe10154e43ea7f8',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/57564954b5d9bdd786179c3a8def6ccb.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47845bbeed93d86da5ea9200d1ff04f5',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/25b601e4a47ab3ec654d74f929dc14db.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9bf1ca0c40ea04b9d16efd1bcc1d2244',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/9078aa260fd3dd22ca82849b617b3dc1.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac3a387139fed78ec06f089b31427356',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/8800c3caabf18c92f0a020bad42cf421.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2cd1d88e237411acea906b91593a314',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/5fba340285fc37e3d0b2ee702d1f1e20.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c4a53c44cf5f09f3cb051d97224ad79',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/b761395c7a6d16c8551974762da2e15b.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2eb5ee232f06b45d25b5a40edb16026a',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/bfec1b64a57fecd75b86acb45fcde992.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a719915ccee14dc115036970ad8af85',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/6454278c414611f7c70960152cc4100b.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2661bc69cbbd6bbcec4d1cc17304211',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/215889ca38250d0662477eadf5a208ed.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f63c87c59975a7ca6d65c44acd1e7d6',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/0a36f8ecfd91766193d9596d888664ee.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ff16fefa583d07a470261aac7093635',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/88f8075aec6ffe99290c6316d08ef9e2.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b2dcc7a101bd67c6970c4be73331277',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/c475ad67c4f6c68a57878ac9c3d8607b.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '701d8a3585b797897445c24f61f89c66',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/0f4e2d70ed8abb813b21949075d1acd1.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3386f86f614f7e395fa7032c9c7e314',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/4d612a86545a873279a2c9d94948f6b6.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02332070e491754cc193e75f0b5d8326',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/9f6fbf185de5e4e02d3f537e4e66d3a0.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4b32edd40055614a633a5b17ecba0ee',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/d410a0cf0bef64e46feed27a9779d180.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c4c83265170685d8b77ecf47e63f895',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/709986dcbe79d933c2b3e6266d29a324.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a27d6e97cd19d5cd12a90e414dfed34a',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/875d441b907f02969c4c7ffeaf29381f.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f30a170d29f92b85f46579bdb99bf63',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/c6dc115a0790e0234fc3bc8f780d75c7.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f1fea048efb30620465765532d087a61',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/67c2e80c0a9cd154d5add28ec2511489.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30be6c31342330e5bfb8394461570f9d',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/974a56ef75cb75dd92da58fe873aa634.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a0d7ac5e83cf865bb6b4dc490070f45',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/aba06b4208f6aaaa460aede05a541935.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2113fca40b382180e9e393a523ca5430',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/adc344e1e16e9a4a5b8b34949e84ceaa.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7dee6104bf2c7947da42035c8507203c',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/98c8302d3e42405aff882a47ce2cc7be.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f64e4e993ad9e8b1ee851f3642fc2024',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/6cdd1e09da2695722e238cd170e7ef42.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2ac599cfa620712060b0d8e4e111140',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/b58dfb3f7fe860f91916939e43ee41f8.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '419012052c2be0f5216aeee4cd632150',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/f1c6c46e2e23dde81b1a3166b3f3e264.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f15e63b1a35d699ec6f31d6c6264319a',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/5a67aa8c300d0b1c5d03ebd6fddb03ce.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83b655c3b77f701ec4ba9250f7374992',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/a790f0a6779d413e90e6ca9630d015f4.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c437b3f1992d174a912b6e32d04c5dc0',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/b8ff83e5bef96a87912126405d38a3b8.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31be6fb7e7f4479a121d44071bc325eb',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/95deeef020cf41d033f16fe8bded12ec.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4dbaed6b647d75474967b0e36c52a40',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/5ee2834372439e59463883858f26c1da.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c222617f6d0994b355ebb55cdefbabc',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/4373b8b6ac780696c3c7d76ee432d550.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ec64aca8320b6bffbad39c5c0be205b',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/4344432b00b6d13626c0d17d0e59cb0a.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74061dfdb4407c8a78b2e6e8b5c8b82a',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/31906bc5c848a485b75d1b4cbb98181a.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c82f2f29e71f2cabbc21cdbf2784e92',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/ef50bd64fee56f685595421d91ed30c1.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eadb4252894fef7a61ad6c93c497d49c',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/70cdfd86856598f2090e6387cd6f4e30.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b9274d43f0f4c4271e1dfa6f098bd23',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/934e5dc125a768ac7df74e84150af7bb.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a377617b191fbebe1d00244f555635cc',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/ef842052276c95826ae824b4556ec6bd.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d95c4a40bd0a8d8bae85c6e7ff110e5',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/028b5d15b3c5c5f4bbab58063f72a535.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd5e63b16e46d13a4d3c14e7632c2f08',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/1a118c9ad5b02cb7580dae22297a8606.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78405245db8495fa4843d41e9a6e8346',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/044afb42ac27b6b86de86a1f05b58d1a.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c012657d15b71882ca85e3c4dcf19cf8',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/d1a3ab9b99708c4bcccd642943d8b59b.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3025a881de72bd354f7cf8f876436978',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/ce4f61d749754dd3a0dfc084d404f1be.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ddd764dc5575c36f0726f066312d9e06',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/56930bd5846ca9fd7c4d16571e5595c5.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58384b4d2d8f755e82f63b945141dca6',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/3bd74df9ab9c6cd126f5774bd8f00a19.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1cee5d5817d7a96e00a04ea13b781592',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/7942b641e56eba7635d05c3019208688.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23b7a92d40b6f264d2db6d683c84500b',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/cb1b6e2dcb3b3d618018cdb8ebe6eb88.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7e89c0d52883614f319c0c936bd19b3',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/4422d1f5941a408c6b1de67860cd9c43.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '772ae104ca2aec68b524c4f59c25aade',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/e141189144317732518562477e5782ee.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a52d772c4374b1cc7dbe26038ab433b',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/b5e47e1bc7d8459971d360049887b344.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f27f1741a0b08cc15610bf5ffcf673e',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/7e0b83bd84703956c56980d5a3052672.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '699ac4b005ab5ec77e14fbf543d276d3',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/c2a4139cc38f78e7c3aa47320f3de286.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '687e486c60e854ce11578861eadc44db',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/5bd0f9dcf23a0af78a11292f592aad0f.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0f9c755078bc3c717cb2e3c8cc123c2',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/91b5e43f64af126db497adcc55ef13b6.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af7efda9727a5aea4e62bf3f553aa10f',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/cbe81f877e253a99bc4a71b361098cd0.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e141224dbbe5c9774cdbed21294f3b94',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/113c0887f2e89154f841a4923313c666.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28054688fe26e5f7791ecf94403d04b6',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/8c87af4fc68728a546e18ca94f630aba.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e96fc8b414add6841f06399546773da',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/5234970a62a7d40e656e3d03fba100a7.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd49bda276a6c16fcde58f1287f55853a',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/f27aca1d245b4d84fa530970f9bf64d3.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1c28e08e912d58cc0d7690f46de97ca',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/adca341b4572cccb967c6eb8d60c11f1.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c621934efcc43ddd8e683d17ac874e31',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/5552504d72672c87cd8395585587aca0.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd987b946af378db06330e45599fc225a',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/40cfaa5e83799e3905765e443d9e8974.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da397610010a68a6a6f30955dbbae342',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/c29bc0eef10f71f611c286be79592f67.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a2cead8f04fd5642ccb35f8a9773aaa',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/8865a162728a40386c124e9e6b6b2bba.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72b1c4c551f8ee479ab06070651a2c99',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/c1c7ae01349734f0f4cc21ebb244a5f9.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a85bb1bc98064f38604328597cc4a99',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/69b2fd0daf22110d04d80f96e9c56b8e.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c8570939fb89c19fac8c7712feacd98',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/55eef5490b2c080e16a485826b71722c.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f944282bf5e8a526e98dc95b2130625',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/b5116fc3b6eb7e26bf152b99cf694016.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbf52520100f13755766c52a0848709f',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/6a1332960d5788fc703a138ffdc42423.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb80a343c9c88791defce7840b2881fd',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/a493b15f0e92e91f071bd1033920184a.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b698ab63948b231d3dbc817211e4f069',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/8b9791314f5a2eb8e744612d7b7f60d3.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69bab76df770eab3484a868c4ab763c6',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/ec478173c68e29617aadfc81ceba9f06.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '719467c5c9aa7761bd7b4dc31dd85778',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/c8acb93fb0cef9a27992b8bdaf3030bb.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cbdcd41c0ae903cf396fa4b60951ac8',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/b276eba35547a9c82182851cf1b22d8d.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4879618fe0a4f30f09ae2381d7c226e4',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/ade462fbba15db341891a4ff43d08280.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c747129738ac5caa28968e852d59e236',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/33d9537ea9c9e4287c2e47ea432f9ed1.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '907dc9761f5209fc7a3f88f23172751a',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/b82e95430ac55971d6c3ffe84d80c08b.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3fe808e6572fe3c3a1c33e1e42decf3',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/fe2d162746e16645ede67a2c3aab1200.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b89837fcaf97630cf2c865fe73f7cc28',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/9c6645f1d86d0928e766c3f57dff7775.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c365a34865d2414be6969a9db720c665',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/6f6be6dfb17f9859b45140c7798c2b02.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '516da627ffe69bf2c38369da5ec16e06',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/9f1a344ffc97b1feb7348a5ab9e231c0.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1f729e0b36721ea19bc98e80a4c342b',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/394ee683f6dccd01691f10188a1f3e15.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0097159deb824c6e9289860722639acb',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/0fd87e99d08be0c5ecb425211514be6e.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5458008df05c9fe748bf0c64653f7eb7',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/2b60c565b659ee5751a2cdad1877f9c8.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9cfee04522fd7c95f8ae3114adde050c',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/cee23379512294852168b908a22a962a.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54f3f3c184f87fa297875d096ad10852',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/2b250f94e930eb131663f68a8f06ebb7.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e26f013c401076d2006b1e01ec797eef',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/267a2eceb9536aadae5efcda6d9a3ddd.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '633b52c5bb4c5c7dc67701d701d2d356',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/fede91824a40522384521b9f5092510d.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '807892ce9e2f64cbd40a9f39626fefd1',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/29f07865b9775727ec36aad29b838a07.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0b94458090d3a3b4ff22dd83593c02e',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/56144a42041dc7f7a0c2873d84be779c.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7b4bffc823fc2d3a60966cc165c296a',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/329781c652b63393d7549ddd2920efef.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4aa61ec8b849ac8c03a8790c3af9d4ae',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/2166d4a52394b4669cbfc269f4dabc62.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '165094312a989e4f5bbd783131d09f78',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/820a4fa022df4d5161872dc85e476522.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9c374cd1652daf96d1c76e200c96da7',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/1b23b9dbf5c024774c948f082793fe0c.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b7da0106a172a1055cf81cce4972cfb',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/3db41ef6e45dea2400863821a481b083.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62415100ba92fc5c645110e2c2afab6a',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/81eb07c2a427a1b0543e0091b03352ba.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a8e17b4533bec0a78f708d876ff334a',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/d857ddfb0ae537e9477cff465f95cd5c.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd409072f80ef211595863307121781f',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/9724360fcce1f318963e9b3c21d6c99f.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01d55f084e55b9ebd49b60f114096056',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/6a9dbeee2eef1ffc462b487d154d6c36.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2c904e79f48fa2c700ac094475755aa',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/7e240c87fab6b981cd79a3e902b2ea66.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f8315ae1a76bda18f90c6c459c728ba',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/793d05ee9ff4b0f1c79c267336f0e909.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76ce24cd7715b09b088b689327d9b12b',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/f82b630fe9e0979f1d06e4dfe6fa3f9a.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eefa70f088d76d784ef340792209e318',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/6f191b1ae15ffa64fde985fa2322fec5.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c7fa1bc6cc6236c61d3e42d4e1cb07a',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/28ba2a062fe96174035fdfe2e8fca337.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0099647773490738b7c140e99ee8336e',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/94ad69ef3def3e5d8d5c10e7837dceed.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c3d25765019d9b7a0b5143a9815de7f',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/31be2df530c4f377bf938a320dc95f9a.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bee473cc41fd393dfaeeff9515e99a1b',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/3a51aad4dbf6010767aff35d58510ee0.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80ccbf93ef2126cb0432efa0b878bd7e',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/b5be420cb2d83e775d9bf3bb29043029.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '074b0eb3c7adc9ff21daff0951c51b8a',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/8a887d241d2bdbb717dea2049b87ffd9.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e6b48673a645dd6f5a5097602475ad8',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/8ff2d6fd6ae97a7d81c79c0fcf51ec36.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6778a725764e9c5df82ade090ec14796',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/e80122d4a2b0fd94a05ca909be728dad.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45f79149b95d49a3d6a127cd35665afd',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/1d0495adb3933c147b073445cc692653.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b701e640800ac5f649485a0d43b26e6f',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/96b68c512705886c27f081f045d0bfae.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c503029fb1e2ce4ca871ddf6cf076b32',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/9056d72cfe68d12fa5464de981fa8ab2.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7212cb82b46602e2397f7fda478080b8',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/5731ea8052d296f77921044927cda481.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2912ec87a356543254a8be73b895be1',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/6eb566318bd1a0680dcc8e240f6a1816.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65af77e53968b6d1eba3937a193245fe',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/b38bde5f733d2e28d6c22ac3603d3644.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53133d9f5bc58947053ac39f36a67672',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/b218852dee6b04a13b9fc1e5483bec36.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cad1c1b331dc9f39756cb759529f2247',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/f8131b2c25292da7d76582924ed409df.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3a320fad963fb385f64a12c0fa7eb21',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/4472c32181bc5b7f1745adacbd522bd5.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd62c4472f4d6cabb199459fe91444f8e',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/059f53ba51433e4fd264f5a7e1628de7.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0ef9861c5393562d0e2c11df5872192',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/3ef84d5b801ead01a58a7c98227daf3c.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2359226db239f2a5a1645f6014cea917',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/d768ae4f45139d8c4f44326b3919c857.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1beb0efcee01beb9dceb82476471e687',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/6dee1476f1403bf3aefa549e48bd32e8.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7726dade21d24f959c327a9c11894f45',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/3695c87b15c6d8c42677d8e359c0f057.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57be8167f5b53f21da3470cc15180ba0',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/b6c9c55fd8bb5ccbe53ee70b5b658b5f.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e11c6e6aaa7dbab000ff67d3cf259b7',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/21dbf35613d3a54b903fa3a5272c125c.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfe1769d19020bd572c5e13ba6ed0c70',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/72cf399a073f722b507a0a21da3a0b22.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '831db59b55eccaa240cba6e1d4f046c1',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/9995e38057b03ebd393c5c87675669fe.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f10f14cff140225c3c48b5547e4caf4',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/30aac2aae74a3887aea2c7dd0b4cf736.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7729414d3e819e4b247ee45685fa7917',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/3347895b8c10d3e8807fd8619607c126.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74e2b43eac1f80efe72a1211f6a4ad12',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/1f154c7743ccb54c9fa2b0a13a5532f8.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14263f3be7c4b10cfc743e1538e44031',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/eba9c6147312aa234948b38a28928815.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '946bec8952779e019aa5db267023d610',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/66791ac55e0a3d3d6b9667eebef97e48.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ae3b8f612b9827922fd8886e1792bb2',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/35470cbf5d9f04b465ac29087b2d562c.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc3127728aeca2c298aa4789d2b5f289',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/89c1ac401d652c0661bb543f503a20c0.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e35ccdef3baa166c8cb192e5e23327f5',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/c9f6ba67d2a519ae5b68fbb3707ae8f1.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b95c6700a1a4941f0d7f7412773502fc',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/c5f48bc7ffcc2a58d1b23f2da61b2470.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3202364dce8131f2ce9a771db2e0ebdc',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/670ad4f3e61064501c6f0fdddc8fc768.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcf31d1ef58af0be6295e5f138c4b7d7',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/8e85ef20ec3b90be1e7cf6d643bf5919.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '990fcfff97517f7222c42fcb10da2d24',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/e986a395eed8f86ecc31f0fb210c3d5c.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6b999f5f8e227faec2bca8a2744b674',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/4e27dd11a35db0b2a2167774d8df7675.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d75a7a22e073469139de5bcda787c3d',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/eeea41f5493dc11be780c61b70fbb0a8.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9b60954f62809a7e8c947232f7e7366',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/c715cc056f4e134a4d722a5bedc0169c.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d8931ec7897fe0823109eb8d986e502',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/e62e3a816b82c0ad81b8a06c5807adf4.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e05b69d3107a6bfae2b3e66d74ea09f9',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/cc73cd7d4b470bff2758b22bb7f65837.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4c76dfe1997996d6337c15dbff861a1',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/2dcb4c2f1044589b59b69d4bf2418e1f.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8ebdf5d1137cf3ccb29b4e4e284a32e',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/90f1b941e31b9098b2876fbdd2d56d2d.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66d2deabd115bdee1a32c99bd4f2c501',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/40d12dbdce343716971abc58bac8dfd1.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3003ddbf130d51291969014e30492b79',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/60347545399c1a516a901e94726adaf3.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef1d74aafbd015494b2b7e6973b5a9f0',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/b41a6f68e21fb2b78fd9ffd83f192e7b.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '099c4b5e3995051ab3bf07e367f911b4',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/2d9f10ba0c16743350ea03d501f7f769.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '238ed72a54a3aae06c4c6b9efad426d5',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/7fa49f0625eaf9ead009b625da1b8d29.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b1910479203607d1902385fcfb1b9c8',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/ccca71d1cf272c4b86ba641d8ee5fb2e.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '127c37be3f4fb0bf0524ef69ed87a3e3',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/00cc5958fe66f74a535d409cd5e62217.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1661e22f5359c2f522e9d4f5fd769126',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/2608cde42f593243d63047883141ead8.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb85188325a3a124559561671117091a',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/8c6cad3acc6f23b01dbdc4e3c56361a6.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96d2944e08193d1930667640cac85697',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/4a687e7478009a79f365cda889c178eb.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11218810dac4c4eef0f0bb1402c33690',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/1a16a353c1e8ee570a6ca33501b79350.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fcad17e1a5d58594211fd75669904ae',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/85e7876fb9d36aa57aceb1edf09c5e61.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4b17be035b838c6ea7187c7e804cb1b',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/f6f831aff101c30267363166535466e3.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6ee397151932c22294778a657ece5b8',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/92f638cba26a1c94d358ece3648122b7.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f3365953df4ce52a05849679e0551f3',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/86dc0bb75b80175e86c57cb5d6061832.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7eb15f0950435d6f6fd20a837e15e407',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/4a21238073f3de009e099fb8f8c5342b.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc9d4b81908fb8298ac44025c3d3fca7',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/93a568117ca9a8da811118fd5d46465a.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38d87737174819ffc6588c4c84a74731',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/c97942160d2a9ab45c95d2f727b41bdf.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3fa5ed41d8c59f379ed8f5e5dbc82da',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/59fbd8466d9bcf37882a44ba0bfbd115.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9b89ed2e63bb13e5b63c9b8f974b1a4',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/5b58c96511139f3db0bb359d16a87424.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2af9054f4266d0684045797a3a35f1d1',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/f5cdca31fe7cf683f0348bb51ef3f88d.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5270124360ad62c398a35218f83038d',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/e40df1bf8fb11356962d965b4458316e.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cabde35b2bb6e7b8c7e6d02e2ecf510',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/cd08ed2ebc007a3697a24f6944c67064.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1773652ed448436a7102a413d75dd382',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/0f2ec88a65a6266ea3d0214df6e0c981.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99aab1cf668d1767c4dcf974b4af702e',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/80dfd02e67237505b13063d91173a691.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b78fc556a1c3460e4ecb22e91bd3767b',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/2e540bcc6aa3ec0c9bd330ba2226e60a.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64ee608360e8f8a81f44d1488d2753f7',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/2c8ab1d6d4f3fada8dbaea477d4cff54.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a93f589d9767f805ad03ee0180df71ab',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/191568b5745006baa641072c565f809b.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39cd5fea27c365e117b3f207c2db818e',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/c8d0330530c8ac06b0e34e71a71dbff7.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3298819732a233f0a118e0a94930ee65',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/65168f0671876d1059b9ea8d3e7ad944.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '082c16ffcdf76ee54f52fd05666d1f8d',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/46840e804aaa4b7c21984626d8385977.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '097490026fc9df19a0b09882927fc8c9',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/a28b3ac1bff756e50bad397662e2dc72.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4e5ee85609be31738c540a851dc1b2f',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/5aecc01cb9341ddd67b41a29a7c81db6.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a92b340d4343f070563302a04267beda',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/214aad5a6bd4b2ed29110cc2e412eb3b.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddf6df0e90882250f43bc5a358cc51ee',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/d59b5128148cd251b5172baab33e590c.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1675ba20e500b1c5d7dedfe8a4f6b3d',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/71a23dee5b92b462bed26b03bfcb6bfc.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0996f309e74c1e2c62a2520e100b8ff0',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/e1eff3b0f533e78f7830363e1fc26a5b.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '925480a822360ec1c4ac031c1ccaf58c',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/8fe9eb6b67e27e62cf25be9e2a8dadbe.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '521e1651b3abed62dea7bb04a3d40f2f',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/1d2f0666f1328a59a1b5de8e50a68f00.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f84a55845637723daccf26045443f5a',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/c30a51127fc5d31fb3a09152ab811c9e.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f89e9571b68690a669924262492126c2',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/c1816a34bfbba8aebf006e29dafbf482.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd90b06667b8610987d8bd9f58cfae7b9',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/50530689fa0b1fb11eb7aeffec9fb4f1.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51856c79f626c82ed151918ae9ced478',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/29ab871d3c890794d89404e798ee92af.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bcb0be41c7d1e2d3314d9bff2613e01',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/6b6bdb9ef37b7fe7689aa4e9fb956e7b.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd4ce510dc57b4748af2445de65139e8',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/02c0aec94e1373eec1a2cc8a59411dee.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5ff486061c01ac1e75fb5f58d11e1fc',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/2bac87b3491465999f14f28c4ecc0150.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f374f602067c4794c3e8e8580e9b54ef',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/cfb403009aed4673235d3024e004b737.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2081bb7b2a39f0cd2c376943dfccbb46',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/f5aad2e2fe05affcc8af0b2a5fbfe90b.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81edacf86f5224891bf601663efffbf4',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/8c10953cf2bd9ad92cb8c00a3de6dfc4.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1da69d7abd4f0140f98e0a1e5501763c',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/6ec8333175e80e6e1561b8add90d1eac.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c0e3b09b528c6d203ca5e93becc0727',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/abe83492e9a9d6a9c7222acc105370df.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c4f9e7abdd83750d8d075111d68881d',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/d6e011d3e202be82d15f070a205d2f61.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99ffb3545dd821b019cf27cef666b591',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/8de507b67cb2eccac0b6d4947b077e98.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1c349fd4ed81f7e8c89006255938e78',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/1e5151973cca5e54e6c8e709eaf259c0.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73fd605805d7c42c4b6d6851676da888',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/dd5deb72ea25a71b0ca3f14370d39bba.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6e1c5e421b7ea06e9c0a148fc1cdde0',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/0401fa24dc57e1727e655addcd73b105.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b797d247a8a99e9aff852a6d8e1c83c8',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/2723250cb0ea64b3ef70a340ac351d77.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fad2721781c21ca64377a1418bde2b61',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/e1d4c089961fcc0db1aeca5d76c29318.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b93de5172ce9bf6a6f074265e7368b7',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/bc108f4c853ba036fd7cd1aeb422d625.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0014204aad510f4f5695ef64022e5c8',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/cbaba19ee96f1b1f0fb9bcc694232eab.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44170f7798233acc11bd17ee67f14bc1',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/a2c86ee8a40fef948fe0b81a6e070fbd.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '989c977ffd5ea7e5fe79efafbe008bef',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/16f36632e1f7c5d89521fc71a05ae3e4.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '753f037b9523cc7892ee51bde391a313',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/8078363ea479c51bb791c82e7e460b4d.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbf84a6ea8893e9a3682ca4f79b36712',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/af42272171a975943370db58a5c4445d.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0454b9f587d67312b4f999509710a7fa',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/01c57988ce53d71d8a636c6c0878b2e7.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b3469d82ece1f79ff2aaff7c0c364f1',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/c5d4c75399652ca52fd731586858a913.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8aa0f566bb053cf4be78c4029b33c78',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/dc8870701e7b7d2fd3dbb5a935b92b08.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d53317e5f2f8189ee6fe2ea4c8f979c',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/5e5abca8b523c3223f8e7452e7d500b2.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3b06a2b02f999dcc876e279bb4dd3d9',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/65859db93a82b4a88fc053e5b2915892.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f6d34ca5c19e29964e30817acf5d209',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/45731193d03513eeb2aa8ccbe2707d81.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '617e02daf1776dcae902d7a9b8a164a1',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/e8b50f739cfce82655b7d590c5c05fd4.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ed8c1bc08191d90751ff032505138f5',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/7a25edcc775dd33a3dd598bfd5e8900f.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b84e02320550dd50e2217d8b1e19d22a',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/34f8eb515d255b08df4f55af367d59fd.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be222bdb8ccf35acd9528383d4ef8664',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/6c3e91462397b4512d08755ec31a919a.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a80cd91c2d38325ee04366616626225',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/d52a1704f2ddce405ae6d5c9ef8a8b30.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e0ae17c3c6c051716366c27e43f8bbd',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/21110e130bfa3a769ff68b150039e4bf.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8827d6127a68e72b0a0475fed18d64d8',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/461a853d062a57195da0a03f076663e6.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d9cf48402ae4810448c79781aa58556',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/96682e145772ba19281e328422df8f32.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ca09b426c3d2c4a531ecd9591b8a920',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/2aa38b4d3931a011b546eb6a64703054.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7407557d5b4675b6edf712012372e9d9',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/639e4981a30b982edc32150d94c2c716.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd6088a2861a5555e3d9faab66f85f91',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/42881ba293600f52646542e86db0d21e.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4b996660a2385daad3ef3bd0d2a6d49',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/878a2787e3624f0e05105e7ec09cd7b4.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '628d48eba4f4e1bd22abb8d702ca515a',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/c3ac760a3044d1467cc3fa88eb00e2ea.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a8d0a73905288978c5fe6249bd6c207',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/b5401958c683a4b5575e8bffd2c21ed9.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3628a44b279b738a3413fc92b935287e',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/9a2f36bd374276841a3f9e718dbf0a07.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '356f76c3218db932d08761a84b2969a9',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/cf6fc88394efbc8e4badb4b44919e0b4.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0048d41e4f39ae8c34955d0d4f90505e',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/03637b3bc5d718ffc46313cef2eb4d33.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f01435b1ba281d411179cb3017ecfe4',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/2ee8d288302cf29e25b29d51a579567a.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aaa7697dedd37389374020b2d6d85cd2',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/86dc17c63f7e4177400d9ba06851c532.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba8f5d783b2e77ba2e550d40871b3286',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/13d50ff9a4ac23fa22f1a8d442ec4922.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c5e3d6ba31a7a43e7e1ed7289883a0a',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/96f6e8f68deec54f5099538b3a9a02da.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '051316aafdd61929b53e3bd53c5788ca',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/4e08717ac80b94015bc490688fb5f0f9.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb19bff5bb3d6834d6b224e826ed42ad',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/a99d66ef8f34f7d392e09fdee6f3ac70.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '725b3441747a139a71864bcfde1f3ed9',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/20b4522e520be43f187174afcf11e2ad.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faef5199e45af66ed5c217a0a8c0d68a',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/b402361b7cd76dccbb5576f70bfeee5d.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a966c4f90debd424c78255a7e9ee3768',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/6453865ae81bc2dcedb69a1b6b4d7313.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c0a6a644982f2f42d53baf4fe422a22',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/994991dd53e63a3095458f0332c2249c.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dca58b88b661c1e2d184bde3c3b9c315',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/f27592e83c5078449d26c0eda77b96ea.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ace0cbc061c656fe6449d81018f1e685',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/dbb7c200dc71e93252fddb13b5b5b57c.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b568cf15b49a31f01a0a09e01658bbc3',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/9e5440e94b6f080839d2ef11f7323aee.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '841f0a43166749bf7286558af6b42aa5',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/133a1e793e1d5d8499a36161305b402c.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30d8a56c5a91d81efedb75ad05b61f8b',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/b1859c6cd9f40db75b4caf6958d61329.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4a72dd5c4c29d64aa9f237cace3144a',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/5a64448209dbe3fd3b269972986f6efa.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '106ba7c942a52e760aed610aa5a6cb58',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/dd52e491ee98c05dc8aca8d0b39e3010.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd9023ac938842c1630518144013e6d2',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/89d3f1c6ebd51f85cc08f952d06c855f.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58969bdb89fbc13704eb1a94e8650af9',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/dd91ecdec84c36262ab4afab6f82da98.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab54dd985360797e5cf12c11240dff04',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/5b71f3c771f9ff56493608beea925820.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7952c3c8c9b7b60a5bc8868f38b1f381',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/ccce11ab966e30347f9a1474ad23ef59.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57e3bb91682d03c1ccf2b73d93366168',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/8105cb2090e0a6d7a6b444f4e7e80f16.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '506dcc92e9268848f0cec7314880963e',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/746b0367c4cf733cc4e87ad329497834.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0188406108e751ccbe7eb8d2ef28c42',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/273eeee7437cad8ba5ed3969f2b12e88.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4d086f88ce29b34bb76374b54c1be91',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/e070a50372bc0823a329ba53a846f8ad.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f481b8b8ce6886b57fc6127e8e55e9e7',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/027b7b2edace9aa29921cc12a912da57.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74b3d4a99b2034eecdfa459ac0733a95',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/f194bc3efa6ff6b9a24b1fd7da1ce0a1.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8478918958b149d539d1bbf724460b65',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/9b4624fd66264738fcad2da1de54a433.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e39ab3d757ec721869decb4e1bc6f7d3',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/572d4fa390a09089c24a3ea4ce6e7b73.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '833146713243a7b841e13bd06fc75d0a',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/8e767bfc98761c61651e12fa3360ddfb.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87f71f084dda0bda3bdf25f04d660ef0',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/b54c1f593037ee29a209cc173f67b055.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9e8585a3963a1d9636c940d0c9b1205',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/3043baecd59ab4b089f78c5e2dc6f2f6.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7120757668668b988c05da4b9450ffb',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/b47a34e02c90a1b28524ad370910faef.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd68b50274b29e75c404d5a3be9139d5',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/d7bf98f15f7f8487ac39f302bfaff145.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecdbde41e98f7438e695e4ea417a312e',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/a37421b843235994d83f6d082f42759a.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b56de047b1b6706f45b89c7e2ecf9ca1',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/9510391ba11aa66dd82aec284926b062.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cc9d0b483d3bb404b410746c9ab34d0',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/1a292cae678ba48ed33442921384e5d2.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ad0fe1074e72f2818cb1d6130c474e0',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/4bf63ec7e5b6dd336de04634e84987b8.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf2c72ff89cf599987a0bbb25114efe1',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/f3f7b028d852a69e4a2bfb047be109bd.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3866fabd19b64af845301948c5ee89c1',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/a40ab72013729cd3518d3f62967e7896.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bb208b95aede76ed38c337cfe91696c',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/af57f217a8c026e48c4df43ce4fb41f1.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4b0628ee482de1096ea2f7e767da6f1',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/bbccd7888630fd1c6aa1df406a046274.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fbfa852be0f72fc0f4fdc0e2aa6313b',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/7989eb5e95122402b2f610e8584ef558.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41ad757254f83231ff1d07d8155bc50a',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/3356c1841e1c94aa5bb7f8c41726f668.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f5c5e9954bb62a2b2e2fe6094958360',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/bb33e1295ab91fc5b2439ccc172afea0.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c7312a06e06eafed3d046250f2e7cb7',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/52eecd9dd9e9150608bc7fdde5961985.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbdb482b518e71c07f8fb7b149da79ff',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/aa11313534c4867c3e04663c428c79cd.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34cc4d25d87f1bd31025ef3aeee6879e',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/e44c97363a8bf68b393d0eca1485192f.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '977d4d49e2097e264b0ae96fce58fb8e',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/730afb8c26b66537a51eafba8b4b9baf.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a170ceb1bfaa9399794d8e0d8ce4392',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/5e7efb74be888f37e5852ca0d6109956.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6842660e4b6623f869aa68905859ae9',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/fa3ee575fccdb2142ebc4a703c698b2c.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d29af2833e091b039354295cfaf1292',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/36eb3b50dea94212481ce1668b50fe9a.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b30f4e5844d19511bf873ddf569e0007',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/746e873094420c8760a5351ce10df072.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d965201ced39ba69169019ef9ac5f71',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/ea2b88abee1c0bc96c5e20ff339952fb.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edbea1505383d430744ed71e12822f0d',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/648ad474749d7d4c92355078213831b5.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce8a8f9423bf38b103a2beae759b658a',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/b7efe7a3a2bafefe0ebdce37813a3be7.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fd123a8c0152c78daf6366ec2bd6103',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/1cd7c88fb4313b5575e83f05ca40f0e3.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7ab2e0f5d48a943a7828c53f1778d3b',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/a3bc2c7ab7d7d3468cae67451f88e1f7.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '911ca749fa2b7d50403dc524c1bc5280',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/909a372de457202d2fc932274ee3226f.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '531d9d85d137cb26abd820c7a32acdad',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/1452f6a53363f0c3b07144daf13f71ce.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e34cb8662cf636e809eb87aa79b542ea',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/14bbdd9160c594a2472a19284430c2e4.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a63285ab8369cb5598a4658f136940a',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/2cc34401d0dcabc001731d4e3c790ef2.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '651c3d9c85bb5aceebbeffb516128ada',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/ae9f100892a631d4fd20fd52dcacdeb1.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fdb7c87c036f84f574e6de9647effd8',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/da6163c908be2cb2fb0c4c4124cfb477.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3a5744415660bf352bf0258408d7c0a',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/06f6dd42c997ecd751d31d07371ded33.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b62d7f44a9a381f50626c7586e712386',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/3fe9512f625932dff5de4478f704e0a3.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca2ba10cc9388dbc5b58582ad6fa9aed',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/3ca23a132c75f046232cc506ecb78d7e.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '069d267376098f1d30d887ffcacd099f',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/4c9aaee9e0ca8211e048f1c4129d6228.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '968cbc4c933fcc1bac6c9a08143f7363',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/91744bc91d85b943d03745ea9d9521d8.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4aa1cf8aed8475e8ea5335a8f374b4b0',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/f5245851620c93ab202259b13f517661.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b22b955347a48887da1a1529a21fad25',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/c2d05b49bcc4b519400876ce20d269f5.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3acb60bdbd1f765a7fa523e76b2a7a6b',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/48a0ce3a230213b0ef029bd62a69b185.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e7e0f3608535600c022043d4ba3ae17',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/113d70c6d2666930b39c0760bfe56a1e.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7f8ed5ab00eca9625eeee3c3a8ed127',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/c799c172df3b89991eab24e578022cc1.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '084e3682f2653c9488bfd0b496838410',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/f31b595b8d2c33facaae9e495d99e358.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83de759f10f26e89c29a43f34e8b4059',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/0697447e308f5d3127d9f1fc0b4e386d.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f1381fed5deb1b79436cf9af5b91af8',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/dafc311301b7499aa39914b2ceff6ba5.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebe0336cb877a154c50aa79dc879c348',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/1ccdf70f1705836595521fbae9194166.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f862ef6d27e33cad15f2c8d6fdcfd84',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/4fd1415af6f2f574369c5fab1680d2a1.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76066b9679a186d56955034ecadd74d6',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/94225cd433824df634f3963b78090314.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1b5a2316713a0566507473d9fba0049',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/f97cd40f0882865a4907c9fe610225f7.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e17f12f916ea9d628daf786298a2c908',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/4bdb5c97c5e5467d830ef8c9f557fd53.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84ceb90ed231b8c95d5b3c2720db3703',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/8ffe6db9e5a98eda0f8860175bdc0bf8.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6f7481b1480cd09b258d58fbbf736e6',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/63f78ee2970f039a9c2d630d7f40540a.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c5ac0a4d03f2b8a26e24fcf4a8b1877',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/c29c2f6faeab7117f7734cf5bb069149.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a220cb51cfa673bcdf89d36ae0f74fb3',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/fb7346e5e2a74ea6e51c0d3b39cbfaf3.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6129b8923dc672e4039c147bea976bb2',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/db04307aac51d7266bd8a89494479737.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a19a95ed81c7c7210e928f046251a55',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/0f7b632120266196e5eb0b053558f540.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bcd7ba62ae1004b728de656b0a7a52a',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/abf2feb7de4843908a121e5c1c3ec3f7.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'caf5fab9b490a602a5047869d4f6cb8b',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/c376506f561f7a418fa2f68c87c5497a.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08507fd8180bb49a6364655ca911d228',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/e3d84a9376365374cfa20992bfb75f24.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3808be488ea4990b5bb17e2c60f3ae0a',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/e050d67fd171d4d9d88fa506a1bcceda.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c271bf4e3ee5205ec54e5aa3c1a94a9',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/a9beb41457ff8c0e97778b9c95037684.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0865f9442ac5d04ec1139ebfa4e5b9ad',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/29b1ad4e83627b910dab0eac0605c500.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83ffbad096c0c264bb113ea9d7ef79b9',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/ab138f6918f4e39b861f8c0a7f5b321c.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b06c33e914ba6d3635bb69a88a50be34',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/1503adb552f3205a599e3866374eca69.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b57a59b49567018c38f7f6f67dba5060',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/1d29c5ac40e99b353473cab45619c843.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2392c6bb56caf711cec2391f81a4695c',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/f9892b0488d74613abb3451ca2a60f75.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e30c2b408c426b95907628c3847ece2b',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/389c693ab39f9e2c8c065ad40e5f15ef.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9650be293d52e9dbe86c100461c808ae',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/5cb72675ef61f2fe16438a38c9ae0369.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b7d554a1c97c6c4f76552dd11e0c75a',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/d8cd145e6d434bba3e79d312f9f58518.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c879c19e86ad79176149e00f5bf0067',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/2ffdaedcf418e4fc0ec7de56db009d54.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1d5a59fc95f8172d3342a54284cb81d',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/ade524eab8193322cdc53791609a40fb.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a61d32cd3f0e922e566c15579f29b60f',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/81f29fc1117c45dea5d2ef37cd84986b.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d9297e4af1e9358ea1ce55ca12ea948',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/029ee89487bdcac48700ddd83daf766a.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '532a8974dba374520f7a8467449ce125',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/13657e61d567d9f9896ac590999c6ddd.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6de3059335c17fc17ce82ff7cc7c5af5',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/4e6ba7c1b567f571a0771f3977ba0c48.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd7aecfcf50b2ab8534abaa48b491248',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/1bea570c9ab64646fba279f3d9f24cf4.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f0d598726933772b813d5b4afa1c8d0',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/094ac7be45ce8e68831460c7c477d645.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93a17044e6f89b966e5b0606c55c4786',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/1df75183a4aacff22432a2cd3d749507.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd439e8ba4624abe682523f595da80563',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/1f96e54a45277a3af44fba5c99804c75.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7eaf21bba66aadb6d12be874848eeed',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/46dd06fc88265800c53618d718a55331.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76e3c26791eb1eff94655d321fbfbd97',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/febded8070720462a8685142440d53cb.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '2c592f6dcff6bcba71ab626c018c257d',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/07144ed19929f7e767e7d2d4ef958e69.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '60e001e6094d0b621f633830fa466e3a',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/1af944411fab8c563969376ec3d3030d.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '3e434c5160e98bd4a3fd80e087de6eea',
      'native_key' => 1,
      'filename' => 'modUserGroup/3b93a5f1afd630d662c360c0b2d0a509.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'c7534de5bdd50f56e667612549cb1356',
      'native_key' => 1,
      'filename' => 'modDashboard/0c2afc5b5629e79e3d4c2c410ba54592.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '1a2b24b29f0021e4b1fe484356b97af8',
      'native_key' => 1,
      'filename' => 'modMediaSource/b7d9a0f54fd804cfdce084c0f5f9cdb8.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'bb28a13c51be942f2a1b91e0b5fe3a15',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/dffa858d093690cbdd1f57ff1eb39dbf.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '647889b159d00c069b6afdcc79a2c698',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/aa3dced1b07aaa870afa9be9f05c0213.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '83e65dc8bdee68241e4aee17c692fb7e',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/bfed25e6d34e24063bc520680181040b.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e47ba3dc91811ca70744aba2a1b5e959',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/05eeaf8374c15f8bc7de7c0f329a7508.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '5a57af4c93d9928fed27fd9355d85384',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/78cdd166f80b08f458a8adbd4cbbfff3.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '4bf7e71763a8b13081f3da3f10b5d118',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/b21a687b4973a75db4b27ee327e191e0.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '0363d9c41a8566dfc2164673f5effaca',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/6f239d1ef30587ee1a18e513de0b6c64.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e6e09b2f0d7381b9918c68fe3b46d5cc',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/b72b492f2c6f06408b0fc0e1804cdb0d.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'c1c7926cc57132fce8dac61756752dfd',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/0cfc22504564d8c7bcdc835703be9c24.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'fff9fcb8971bcbe5c676bcb7a6c22916',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/434de494e6c5ceacaf4aed3bd126de79.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd41e3486c28f24152f3cfeb5dd6de7d1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/04c9440bf395769d63a20f970d70f17a.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd2084a874a3a0867ecae4d439611c187',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/862b3c403019092351154d92ef9aa690.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b6157ad24e97637b0f2f1f28c004dc45',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/50fc6a3e60bfe2bdf82cddc718be579c.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '8cf2ebd7e5d08b2f2e3b2357e39f1ed1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/bd3b90f5a66bf5c5310acf37a0297238.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'f825318714db57c937e913dae19e26ae',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c6c074dc9869d4212fb93fe6c3537681.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '4e794d43b0a2bd304462b1f2a64565d8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/7dfba8e2b95b24e203c744d4a5730883.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '63f05fff45c2e5a00a8cc8f2d655da8d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1e208a435dc2a87729f5a9fdf31ea677.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6d834a2aa7ce78813fc48df86801622a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e4152cd7d5abbddc321b8fcbcd499cae.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'bd47a0b4b9cb71f511394dc862b1405d',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/c61a7ae98e4863f25e58de414e5dad6d.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a72ab1edb014fa556f325c1420b70896',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/be5de9a0348fd0c10486817260fe87c3.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8afea120c9586f96159259ac10f2ec89',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/7e70b138286de1547e74e937ce6d898f.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3f74d5008e41c6ae45e1db7316e0b9f7',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/3cf96f0eb4d193c6941497dcca82129d.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2019f06c5c040bcb3c425d31d46b22f0',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/4199fabdc0d4966cef0ab9bad47f42a4.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '87c072999215b4fd8ad517368ca8292a',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/db175fe406fb8437ccd8660605357f3a.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '827bcc7422612b27ec5089c350dac3d6',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/69ed7e24b71e9fe7178dca29a758c903.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '80caf180d5ab0811a0bf763dd84a1bd9',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/2e32c20a68b64426fb6167f455d74274.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'db97c74dcb82e880c12ac454a66d0638',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/eae3fc3b06da950b7e5ad9324602bcec.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e637c42d93ea4e103966175221258b22',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/ccdbdc9311c279af9b4889316968dc84.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c07a0ad485399ec6bc661dcea91c73af',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/052d9e01dd8d65483f4154ce7c9f92bd.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '4003f77de86f3fa5fec9a3af41e01822',
      'native_key' => 'web',
      'filename' => 'modContext/bb6bd0b1752213dc5a1526ba231b4f62.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'd15ae01d96da6bbfc06b285c04fdbbfa',
      'native_key' => 'mgr',
      'filename' => 'modContext/3d100965c96208e8acf19392f9585c91.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1fa213ebbc1588a439814d81fa55bbb1',
      'native_key' => '1fa213ebbc1588a439814d81fa55bbb1',
      'filename' => 'xPDOFileVehicle/a82eb8d13027e580572b56aed2c5548e.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e26a3cc2f8a3cf53c208291ba3ee6ab0',
      'native_key' => 'e26a3cc2f8a3cf53c208291ba3ee6ab0',
      'filename' => 'xPDOFileVehicle/e807650cac56924dba44dc96e4a0d9e3.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0d28be8b4c09a472539dc5b9fdcb67dc',
      'native_key' => '0d28be8b4c09a472539dc5b9fdcb67dc',
      'filename' => 'xPDOFileVehicle/1865db349f4f63acf866446822919688.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b81b10fcbd5971b4a690dad941a00428',
      'native_key' => 'b81b10fcbd5971b4a690dad941a00428',
      'filename' => 'xPDOFileVehicle/9d41603373a483b009ba42623b2f4266.vehicle',
    ),
  ),
);